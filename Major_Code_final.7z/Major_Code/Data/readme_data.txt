The Data is available at Zenodo. Please follow the link: https://doi.org/10.5281/zenodo.12742957

If you run the simulation_scenario Code, the simulated data sets will be stored here.

